<?php
if(!file_exists('constant.php')) {
    header('location: install.php');
    exit();
}
require_once('common.php');

?>
